# # from . import db
# # from flask_login import UserMixin
# # from werkzeug.security import generate_password_hash, check_password_hash


# # class User(UserMixin, db.Model):
# #     id = db.Column(db.Integer, primary_key=True)
# #     username = db.Column(db.String(80), unique=True, nullable=False)
# #     password_hash = db.Column(db.String(128), nullable=False)
# #     is_admin = db.Column(db.Boolean, default=False)

# #     orders = db.relationship("Order", backref="user", lazy=True)

# #     def set_password(self, password):
# #         self.password_hash = generate_password_hash(password)

# #     def check_password(self, password):
# #         return check_password_hash(self.password_hash, password)


# # class MenuItem(db.Model):
# #     id = db.Column(db.Integer, primary_key=True)
# #     name = db.Column(db.String(120), nullable=False)
# #     description = db.Column(db.String(200))
# #     price = db.Column(db.Float, nullable=False)

# #     orders = db.relationship("Order", backref="menu_item", lazy=True)


# # class Order(db.Model):
# #     id = db.Column(db.Integer, primary_key=True)
# #     user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
# #     menu_item_id = db.Column(db.Integer, db.ForeignKey("menu_item.id"), nullable=False)
# #     status = db.Column(db.String(20), default="Pending")  # Pending, Processed, Completed


# from . import db
# from flask_login import UserMixin
# from werkzeug.security import generate_password_hash, check_password_hash


# class User(UserMixin, db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(80), unique=True, nullable=False)
#     password_hash = db.Column(db.String(128), nullable=False)
#     is_admin = db.Column(db.Boolean, default=False)

#     orders = db.relationship("Order", backref="user", lazy=True)

#     def set_password(self, password):
#         self.password_hash = generate_password_hash(password)

#     def check_password(self, password):
#         return check_password_hash(self.password_hash, password)


# class MenuItem(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     name = db.Column(db.String(120), nullable=False)
#     description = db.Column(db.String(200))
#     price = db.Column(db.Float, nullable=False)
#     is_active = db.Column(db.Boolean, default=True)

#     orders = db.relationship("OrderItem", backref="menu_item", lazy=True)


# class Order(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
#     status = db.Column(db.String(20), default="Pending")  # Pending, Processed, Completed

#     items = db.relationship("OrderItem", backref="order", lazy=True)


# class OrderItem(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
#     menu_item_id = db.Column(db.Integer, db.ForeignKey("menu_item.id"), nullable=False)
#     quantity = db.Column(db.Integer, nullable=False, default=1)

# app/models.py
from .extensions import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


class User(db.Model, UserMixin):
    __tablename__ = "user"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

    orders = db.relationship("Order", backref="user", lazy=True)

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f"<User {self.username}>"


class MenuItem(db.Model):
    __tablename__ = "menu_item"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(255))
    price = db.Column(db.Float, nullable=False)
    is_active = db.Column(db.Boolean, default=True)

    order_items = db.relationship("OrderItem", backref="menu_item", lazy=True)

    def __repr__(self):
        return f"<MenuItem {self.name}>"


class Order(db.Model):
    __tablename__ = "order"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    status = db.Column(db.String(20), default="pending")  # pending|processing|completed|cancelled
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    items = db.relationship("OrderItem", backref="order", cascade="all, delete-orphan", lazy=True)

    def __repr__(self):
        return f"<Order {self.id} user={self.user_id} status={self.status}>"


class OrderItem(db.Model):
    __tablename__ = "order_item"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    menu_item_id = db.Column(db.Integer, db.ForeignKey("menu_item.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)

    def __repr__(self):
        return f"<OrderItem order={self.order_id} item={self.menu_item_id} qty={self.quantity}>"
