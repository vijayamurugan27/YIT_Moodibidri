# # from flask import Flask
# # from flask_sqlalchemy import SQLAlchemy
# # from flask_migrate import Migrate
# # from flask_login import LoginManager

# # db = SQLAlchemy()
# # migrate = Migrate()
# # login_manager = LoginManager()

# # def create_app():
# #     app = Flask(__name__)
# #     app.config['SECRET_KEY'] = 'supersecretkey'
# #     app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///restaurant.db'
# #     app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# #     # Initialize extensions
# #     db.init_app(app)
# #     migrate.init_app(app, db)
# #     login_manager.init_app(app)

# #     # Register blueprints
# #     from .auth.routes import auth_bp
# #     from .main.routes import main_bp
# #     from .admin.routes import admin_bp

# #     app.register_blueprint(auth_bp, url_prefix='/auth')
# #     app.register_blueprint(main_bp)
# #     app.register_blueprint(admin_bp, url_prefix='/admin')

# #     # Register CLI commands
# #     from .cli import create_admin
# #     app.cli.add_command(create_admin)

# #     return app

# from flask import Flask
# from .extensions import db, login_manager

# def create_app():
#     app = Flask(__name__)
#     app.config['SECRET_KEY'] = "your-secret-key"
#     app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///restaurant.db"
#     app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#     # initialize extensions with app
#     db.init_app(app)
#     login_manager.init_app(app)

#     # register blueprints here...
#     from .auth.routes import auth_bp
#     from .main.routes import main_bp
#     from .admin.routes import admin_bp

#     app.register_blueprint(auth_bp)
#     app.register_blueprint(main_bp)
#     app.register_blueprint(admin_bp, url_prefix="/admin")

#     # register CLI commands
#     from .cli import create_admin
#     app.cli.add_command(create_admin)

#     return app


# app/__init__.py
from flask import Flask
from .extensions import db, login_manager
from .models import User  # imported here so user_loader can reference it


# from flask_migrate import Migrate
# migrate = Migrate(app, db)


def create_app(config_object=None):
    """
    Create Flask app, initialize extensions and register blueprints.
    Optionally pass a configuration object or module string; if not provided,
    the function sets a minimal default config for local dev.
    """
    app = Flask(__name__, instance_relative_config=False)

    # Basic config (you can replace by `app.config.from_object("config.Config")`)
    if config_object:
        app.config.from_object(config_object)
    else:
        app.config.update(
            SECRET_KEY="change-this-in-production",
            SQLALCHEMY_DATABASE_URI="sqlite:///restaurant.db",
            SQLALCHEMY_TRACK_MODIFICATIONS=False,
        )

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)

    # user_loader required by Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        try:
            return User.query.get(int(user_id))
        except Exception:
            return None

    # Register blueprints (import here to avoid circular imports)
    from .auth.routes import auth_bp
    from .main.routes import main_bp
    from .admin.routes import admin_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(main_bp)  # root routes
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # Register CLI commands
    from .cli import create_admin
    app.cli.add_command(create_admin)

    return app



