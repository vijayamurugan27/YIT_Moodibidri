# from flask import render_template, request, redirect, url_for
# from flask_login import login_required
# from ..extensions import db
# from ..models import Book
# from . import books_bp

# @books_bp.route("/")
# @login_required
# def list_books():
#     books = Book.query.all()
#     return render_template("books/list.html", books=books, title="Books")

# @books_bp.route("/add", methods=["POST"])
# @login_required
# def add_book():
#     title = request.form["title"]
#     author = request.form["author"]
#     book = Book(title=title, author=author)
#     db.session.add(book)
#     db.session.commit()
#     return redirect(url_for("books.list_books"))

# @books_bp.route("/add-form")
# @login_required
# def add_form():
#     return render_template("base.html", title="Add Book", content='''
#         <form method="post" action="/books/add">
#             <div class="mb-3">
#                 <label class="form-label">Title</label>
#                 <input type="text" class="form-control" name="title" required>
#             </div>
#             <div class="mb-3">
#                 <label class="form-label">Author</label>
#                 <input type="text" class="form-control" name="author" required>
#             </div>
#             <button type="submit" class="btn btn-primary">Add Book</button>
#         </form>
#     ''')


from flask import render_template, request, redirect, url_for
from flask_login import login_required, current_user
from ..extensions import db
from ..models import Book
from . import books_bp

@books_bp.route("/")
@login_required
def list_books():
    books = Book.query.filter_by(user_id=current_user.id).all()
    return render_template("books/list.html", books=books, title="Books")

@books_bp.route("/add", methods=["GET", "POST"])
@login_required
def add_book():
    if request.method == "POST":
        title = request.form["title"]
        author = request.form["author"]
        book = Book(title=title, author=author, user_id=current_user.id)
        db.session.add(book)
        db.session.commit()
        return redirect(url_for("books.list_books"))
    return render_template("books/add.html", title="Add Book")
