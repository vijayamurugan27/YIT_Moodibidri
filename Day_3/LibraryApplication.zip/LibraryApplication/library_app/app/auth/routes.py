# from flask import render_template, request, redirect, url_for
# from flask_login import login_user, logout_user, login_required
# from werkzeug.security import generate_password_hash, check_password_hash
# from . import auth_bp
# from ..extensions import db
# from ..models import User

# @auth_bp.route("/register", methods=["GET", "POST"])
# def register():
#     if request.method == "POST":
#         username = request.form["username"]
#         password = generate_password_hash(request.form["password"])
#         user = User(username=username, password=password)
#         db.session.add(user)
#         db.session.commit()
#         return redirect(url_for("auth.login"))
#     return '''
#         <form method="post">
#             Username: <input type="text" name="username"><br>
#             Password: <input type="password" name="password"><br>
#             <input type="submit" value="Register">
#         </form>
#     '''

# @auth_bp.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "POST":
#         username = request.form["username"]
#         password = request.form["password"]
#         user = User.query.filter_by(username=username).first()
#         if user and check_password_hash(user.password, password):
#             login_user(user)
#             return redirect(url_for("main.home"))
#         return "Invalid credentials"
#     return '''
#         <form method="post">
#             Username: <input type="text" name="username"><br>
#             Password: <input type="password" name="password"><br>
#             <input type="submit" value="Login">
#         </form>
#     '''

# @auth_bp.route("/logout")
# @login_required
# def logout():
#     logout_user()
#     return redirect(url_for("main.home"))


from flask import render_template, request, redirect, url_for
from flask_login import login_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from . import auth_bp
from ..extensions import db
from ..models import User

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = generate_password_hash(request.form["password"])
        user = User(username=username, password=password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("auth.login"))
    return render_template("auth/register.html", title="Register")

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for("main.home"))
        return "Invalid credentials"
    return render_template("auth/login.html", title="Login")

@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.home"))
