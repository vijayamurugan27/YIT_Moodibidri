# from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
# from flask_login import LoginManager, login_user, login_required, logout_user, current_user
# from models import db, User, Category, Product
# from werkzeug.security import generate_password_hash, check_password_hash
# from functools import wraps
# import os

# app = Flask(__name__)
# app.config['SECRET_KEY'] = 'your-secret-key-here'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# # Initialize extensions
# db.init_app(app)
# login_manager = LoginManager()
# login_manager.init_app(app)
# login_manager.login_view = 'login'

# @login_manager.user_loader
# def load_user(user_id):
#     return User.query.get(int(user_id))

# def admin_required(f):
#     @wraps(f)
#     def decorated_function(*args, **kwargs):
#         if not current_user.is_authenticated or not current_user.is_admin():
#             flash('Admin access required.', 'danger')
#             return redirect(url_for('login'))
#         return f(*args, **kwargs)
#     return decorated_function

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/register', methods=['GET', 'POST'])
# def register():
#     if request.method == 'POST':
#         username = request.form['username']
#         email = request.form['email']
#         password = request.form['password']
        
#         if User.query.filter_by(username=username).first():
#             flash('Username already exists', 'danger')
#             return redirect(url_for('register'))
        
#         if User.query.filter_by(email=email).first():
#             flash('Email already exists', 'danger')
#             return redirect(url_for('register'))
        
#         user = User(username=username, email=email)
#         user.set_password(password)
#         db.session.add(user)
#         db.session.commit()
        
#         flash('Registration successful! Please login.', 'success')
#         return redirect(url_for('login'))
    
#     return render_template('register.html')

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         username = request.form['username']
#         password = request.form['password']
#         user = User.query.filter_by(username=username).first()
        
#         if user and user.check_password(password):
#             login_user(user)
#             next_page = request.args.get('next')
#             return redirect(next_page or url_for('products'))
#         else:
#             flash('Invalid username or password', 'danger')
    
#     return render_template('login.html')

# @app.route('/logout')
# @login_required
# def logout():
#     logout_user()
#     flash('You have been logged out', 'info')
#     return redirect(url_for('index'))

# @app.route('/products')
# def products():
#     category_id = request.args.get('category', type=int)
#     search = request.args.get('search', '')
    
#     query = Product.query
    
#     if category_id:
#         query = query.filter_by(category_id=category_id)
    
#     if search:
#         query = query.filter(Product.name.ilike(f'%{search}%'))
    
#     products = query.all()
#     categories = Category.query.all()
    
#     return render_template('products.html', products=products, categories=categories)

# @app.route('/add_product', methods=['GET', 'POST'])
# @login_required
# @admin_required
# def add_product():
#     if request.method == 'POST':
#         name = request.form['name']
#         description = request.form['description']
#         price = float(request.form['price'])
#         category_id = int(request.form['category'])
#         stock = int(request.form['stock'])
#         image_url = request.form.get('image_url', '')
        
#         product = Product(
#             name=name,
#             description=description,
#             price=price,
#             category_id=category_id,
#             stock=stock,
#             image_url=image_url
#         )
        
#         db.session.add(product)
#         db.session.commit()
        
#         flash('Product added successfully!', 'success')
#         return redirect(url_for('products'))
    
#     categories = Category.query.all()
#     return render_template('add_product.html', categories=categories)

# @app.route('/edit_product/<int:product_id>', methods=['GET', 'POST'])
# @login_required
# @admin_required
# def edit_product(product_id):
#     product = Product.query.get_or_404(product_id)
    
#     if request.method == 'POST':
#         product.name = request.form['name']
#         product.description = request.form['description']
#         product.price = float(request.form['price'])
#         product.category_id = int(request.form['category'])
#         product.stock = int(request.form['stock'])
#         product.image_url = request.form.get('image_url', '')
        
#         db.session.commit()
#         flash('Product updated successfully!', 'success')
#         return redirect(url_for('products'))
    
#     categories = Category.query.all()
#     return render_template('edit_product.html', product=product, categories=categories)

# @app.route('/delete_product/<int:product_id>')
# @login_required
# @admin_required
# def delete_product(product_id):
#     product = Product.query.get_or_404(product_id)
#     db.session.delete(product)
#     db.session.commit()
#     flash('Product deleted successfully!', 'success')
#     return redirect(url_for('products'))

# # API endpoints
# @app.route('/api/products')
# def api_products():
#     products = Product.query.all()
#     return jsonify([{
#         'id': p.id,
#         'name': p.name,
#         'price': p.price,
#         'category': p.category_ref.name,
#         'image_url': p.image_url
#     } for p in products])

# @app.route('/api/categories')
# def api_categories():
#     categories = Category.query.all()
#     return jsonify([{'id': c.id, 'name': c.name} for c in categories])

# def init_db():
#     with app.app_context():
#         db.create_all()
        
#         # Create default admin user
#         if not User.query.filter_by(username='admin').first():
#             admin = User(username='admin', email='admin@example.com', role='admin')
#             admin.set_password('admin123')
#             db.session.add(admin)
        
#         # Create some default categories
#         if Category.query.count() == 0:
#             categories = [
#                 Category(name='Electronics', description='Electronic devices and accessories'),
#                 Category(name='Clothing', description='Fashion and apparel'),
#                 Category(name='Books', description='Books and literature'),
#                 Category(name='Home', description='Home and kitchen items')
#             ]
#             db.session.add_all(categories)
        
#         db.session.commit()

# if __name__ == '__main__':
#     init_db()
#     app.run(debug=True)






from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from models import db, User, Category, Product
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-this-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash('Admin access required.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def init_db():
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Create default admin user
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', email='admin@example.com', role='admin')
            admin.set_password('admin123')
            db.session.add(admin)
            print("Created admin user: admin/admin123")
        
        # Create some default categories
        if Category.query.count() == 0:
            categories = [
                Category(name='Electronics', description='Electronic devices and accessories'),
                Category(name='Clothing', description='Fashion and apparel'),
                Category(name='Books', description='Books and literature'),
                Category(name='Home', description='Home and kitchen items')
            ]
            db.session.add_all(categories)
            print("Created default categories")
        
        # Create some sample products if none exist
        if Product.query.count() == 0:
            # Get categories
            electronics = Category.query.filter_by(name='Electronics').first()
            clothing = Category.query.filter_by(name='Clothing').first()
            books = Category.query.filter_by(name='Books').first()
            
            products = [
                Product(
                    name='Smartphone',
                    description='Latest smartphone with great features',
                    price=599.99,
                    category_id=electronics.id,
                    stock=50,
                    image_url='https://via.placeholder.com/300x200?text=Smartphone'
                ),
                Product(
                    name='Laptop',
                    description='High-performance laptop',
                    price=1299.99,
                    category_id=electronics.id,
                    stock=25,
                    image_url='https://via.placeholder.com/300x200?text=Laptop'
                ),
                Product(
                    name='T-Shirt',
                    description='Comfortable cotton t-shirt',
                    price=19.99,
                    category_id=clothing.id,
                    stock=100,
                    image_url='https://via.placeholder.com/300x200?text=T-Shirt'
                ),
                Product(
                    name='Python Programming Book',
                    description='Learn Python programming',
                    price=39.99,
                    category_id=books.id,
                    stock=30,
                    image_url='https://via.placeholder.com/300x200?text=Python+Book'
                )
            ]
            db.session.add_all(products)
            print("Created sample products")
        
        db.session.commit()
        print("Database initialized successfully!")

# Initialize database when app starts
with app.app_context():
    init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return redirect(url_for('register'))
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            flash(f'Welcome back, {username}!', 'success')
            return redirect(next_page or url_for('products'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/products')
def products():
    try:
        category_id = request.args.get('category', type=int)
        search = request.args.get('search', '')
        
        query = Product.query
        
        if category_id:
            query = query.filter_by(category_id=category_id)
        
        if search:
            query = query.filter(Product.name.ilike(f'%{search}%'))
        
        products = query.all()
        categories = Category.query.all()
        
        return render_template('products.html', products=products, categories=categories)
    
    except Exception as e:
        flash('Error loading products. Please try again.', 'danger')
        print(f"Error in products route: {e}")
        return redirect(url_for('index'))

@app.route('/add_product', methods=['GET', 'POST'])
@login_required
@admin_required
def add_product():
    if request.method == 'POST':
        try:
            name = request.form['name']
            description = request.form['description']
            price = float(request.form['price'])
            category_id = int(request.form['category'])
            stock = int(request.form['stock'])
            image_url = request.form.get('image_url', '')
            
            product = Product(
                name=name,
                description=description,
                price=price,
                category_id=category_id,
                stock=stock,
                image_url=image_url
            )
            
            db.session.add(product)
            db.session.commit()
            
            flash('Product added successfully!', 'success')
            return redirect(url_for('products'))
        
        except Exception as e:
            flash('Error adding product. Please try again.', 'danger')
            print(f"Error adding product: {e}")
    
    categories = Category.query.all()
    return render_template('add_product.html', categories=categories)

@app.route('/edit_product/<int:product_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    if request.method == 'POST':
        try:
            product.name = request.form['name']
            product.description = request.form['description']
            product.price = float(request.form['price'])
            product.category_id = int(request.form['category'])
            product.stock = int(request.form['stock'])
            product.image_url = request.form.get('image_url', '')
            
            db.session.commit()
            flash('Product updated successfully!', 'success')
            return redirect(url_for('products'))
        
        except Exception as e:
            flash('Error updating product. Please try again.', 'danger')
            print(f"Error updating product: {e}")
    
    categories = Category.query.all()
    return render_template('edit_product.html', product=product, categories=categories)

@app.route('/delete_product/<int:product_id>')
@login_required
@admin_required
def delete_product(product_id):
    try:
        product = Product.query.get_or_404(product_id)
        db.session.delete(product)
        db.session.commit()
        flash('Product deleted successfully!', 'success')
    except Exception as e:
        flash('Error deleting product. Please try again.', 'danger')
        print(f"Error deleting product: {e}")
    
    return redirect(url_for('products'))

# API endpoints
@app.route('/api/products')
def api_products():
    try:
        products = Product.query.all()
        return jsonify([{
            'id': p.id,
            'name': p.name,
            'price': p.price,
            'category': p.category_ref.name if p.category_ref else 'Uncategorized',
            'image_url': p.image_url
        } for p in products])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/categories')
def api_categories():
    try:
        categories = Category.query.all()
        return jsonify([{'id': c.id, 'name': c.name} for c in categories])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)