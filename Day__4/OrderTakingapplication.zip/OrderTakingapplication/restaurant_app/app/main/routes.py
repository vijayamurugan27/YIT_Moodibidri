from flask import render_template, request, redirect, url_for, flash
from flask_login import current_user, login_required
from . import main_bp
from ..extensions import db
from ..models import MenuItem, Order, OrderItem


@main_bp.route("/")
def home():
    items = MenuItem.query.filter_by(is_active=True).all()
    return render_template("home.html", items=items, title="Welcome")


@main_bp.route("/menu", methods=["GET", "POST"])
@login_required
def menu():
    items = MenuItem.query.filter_by(is_active=True).all()
    
    if request.method == "POST":
        # Build an order from submitted quantities
        quantities = {
            int(k.split("_")[1]): int(v)
            for k, v in request.form.items()
            if k.startswith("qty_") and v and int(v) > 0
        }

        if not quantities:
            flash("Please select at least one item.", "warning")
            return redirect(url_for("main.menu"))

        order = Order(user_id=current_user.id, status="pending")
        db.session.add(order)
        db.session.flush()  # get order.id

        for item_id, qty in quantities.items():
            db.session.add(OrderItem(order_id=order.id, menu_item_id=item_id, quantity=qty))

        db.session.commit()
        return redirect(url_for("main.order_success", order_id=order.id))

    return render_template("menu.html", items=items, title="Menu")


@main_bp.route("/order-success/<int:order_id>")
@login_required
def order_success(order_id):
    return render_template("order_success.html", order_id=order_id, title="Order Placed")
