from flask.cli import with_appcontext
import click
from .extensions import db
from .models import User

@click.command("create-admin")
@click.argument("username")
@click.argument("password")
@with_appcontext
def create_admin(username, password):
    """Create an admin user."""
    if User.query.filter_by(username=username).first():
        print(f"User {username} already exists!")
        return

    admin = User(username=username, is_admin=True)
    admin.set_password(password)
    db.session.add(admin)
    db.session.commit()
    print(f"Admin user {username} created successfully!")
