from flask import render_template, request, redirect, url_for, flash
from flask_login import login_required
from . import admin_bp
from ..extensions import db
from ..models import MenuItem, Order
from ..utils import admin_required


# ---- MENU MANAGEMENT ----
@admin_bp.route("/menu")
@login_required
@admin_required
def menu_list():
    items = MenuItem.query.order_by(MenuItem.is_active.desc(), MenuItem.name.asc()).all()
    return render_template("admin/menu_list.html", items=items, title="Manage Menu")


@admin_bp.route("/menu/new", methods=["GET", "POST"])
@login_required
@admin_required
def menu_new():
    if request.method == "POST":
        name = request.form.get("name")
        price = request.form.get("price", type=float)
        description = request.form.get("description")
        is_active = True if request.form.get("is_active") == "on" else False

        if not name or price is None:
            flash("Name and price are required", "danger")
            return redirect(url_for("admin.menu_new"))

        db.session.add(MenuItem(name=name, description=description, price=price, is_active=is_active))
        db.session.commit()
        flash("Menu item created", "success")
        return redirect(url_for("admin.menu_list"))

    return render_template("admin/menu_form.html", title="Add Menu Item")
