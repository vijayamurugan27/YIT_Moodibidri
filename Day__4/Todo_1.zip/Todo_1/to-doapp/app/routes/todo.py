from flask import Blueprint, render_template, request, redirect, url_for
from app.models import Task
from app.extensions import db

todo_bp = Blueprint("todo", __name__)

@todo_bp.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        content = request.form.get("content")
        if content:
            new_task = Task(content=content)
            db.session.add(new_task)
            db.session.commit()
        return redirect(url_for("todo.index"))

    tasks = Task.query.all()
    return render_template("todo/index.html", tasks=tasks)

@todo_bp.route("/delete/<int:task_id>")
def delete(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return redirect(url_for("todo.index"))

@todo_bp.route("/toggle/<int:task_id>")
def toggle(task_id):
    task = Task.query.get_or_404(task_id)
    task.done = not task.done
    db.session.commit()
    return redirect(url_for("todo.index"))
