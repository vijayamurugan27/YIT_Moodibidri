function showMessage() {
    document.getElementById("output").innerText = "You clicked the button! 🎉";
}
