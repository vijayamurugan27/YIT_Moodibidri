from flask import Flask, render_template, request, redirect, url_for, jsonify
import requests

app = Flask(__name__)

# Server URL (your server running on port 5000)
SERVER_URL = "http://localhost:5000"

@app.route('/')
def index():
    """Home page that lists all students"""
    try:
        response = requests.get(f"{SERVER_URL}/students")
        if response.status_code == 200:
            students = response.json()
            return render_template('index.html', students=students)
        else:
            return render_template('error.html', message="Failed to fetch students from server")
    except requests.exceptions.ConnectionError:
        return render_template('error.html', message="Could not connect to the server. Make sure it's running on port 5000.")

@app.route('/add', methods=['GET', 'POST'])
def add_student():
    """Add a new student"""
    if request.method == 'POST':
        name = request.form['name']
        course = request.form['course']
        
        # Send POST request to server
        response = requests.post(
            f"{SERVER_URL}/students",
            json={'name': name, 'course': course}
        )
        
        if response.status_code == 201:
            return redirect(url_for('index'))
        else:
            return render_template('error.html', message=f"Failed to add student: {response.json().get('error', 'Unknown error')}")
    
    return render_template('add_student.html')

@app.route('/edit/<int:student_id>', methods=['GET', 'POST'])
def edit_student(student_id):
    """Edit an existing student"""
    if request.method == 'POST':
        name = request.form['name']
        course = request.form['course']
        
        # Send PUT request to server
        response = requests.put(
            f"{SERVER_URL}/students/{student_id}",
            json={'name': name, 'course': course}
        )
        
        if response.status_code == 200:
            return redirect(url_for('index'))
        else:
            return render_template('error.html', message=f"Failed to update student: {response.json().get('error', 'Unknown error')}")
    
    # GET request - fetch student data
    response = requests.get(f"{SERVER_URL}/students/{student_id}")
    if response.status_code == 200:
        student = response.json()
        return render_template('edit_student.html', student=student)
    else:
        return render_template('error.html', message="Student not found")

@app.route('/delete/<int:student_id>')
def delete_student(student_id):
    """Delete a student"""
    response = requests.delete(f"{SERVER_URL}/students/{student_id}")
    
    if response.status_code == 200:
        return redirect(url_for('index'))
    else:
        return render_template('error.html', message=f"Failed to delete student: {response.json().get('error', 'Unknown error')}")

@app.route('/api/students')
def api_students():
    """API endpoint to get all students (for potential AJAX calls)"""
    try:
        response = requests.get(f"{SERVER_URL}/students")
        return jsonify(response.json()), response.status_code
    except:
        return jsonify({"error": "Could not connect to server"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5050)