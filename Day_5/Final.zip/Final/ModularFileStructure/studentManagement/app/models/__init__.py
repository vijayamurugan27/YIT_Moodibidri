from .student import Student

__all__ = ['Student']
